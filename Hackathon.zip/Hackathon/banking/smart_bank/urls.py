from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path('', views.home, name='home'),
    # path('login/', views.home, name='login'),
    path('logout/', views.logout_user, name='logout'),
    path('register/', views.register_user, name='register'),
    path('complete-kyc/', views.kyc_profile_view, name='complete_kyc'),
    path('create-account/', views.create_account_view, name='create_account'),
    path('account-summary/', views.account_summary_view, name='account_summary'),
    path('transaction-history/', views.transaction_history_view, name='transaction_history'),
    path('apply-loan/', views.apply_loan_view, name='apply_loan'),
    path('loan-status/', views.loan_status_view, name='loan_status'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
from django.contrib import admin
from .models import CustomerProfile, Account, Transaction, LoanApplication

admin.site.register(CustomerProfile)
admin.site.register(Account)
admin.site.register(Transaction)
admin.site.register(LoanApplication)
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, logout
from django.contrib.auth import login as auth_login
from django.contrib import messages
from .forms import SignUpForm, CustomerProfileForm, LoanApplicationForm
from .models import CustomerProfile, Account, Transaction, LoanApplication
from django.contrib.auth.decorators import login_required


def home(request):
    if request.user.is_authenticated:
        has_kyc = False
        has_account = False
        profile = None
        try:
            profile = request.user.customerprofile 
            has_kyc = profile.kyc_completed 
        except CustomerProfile.DoesNotExist:
            pass 
        if Account.objects.filter(user=request.user).exists():
            has_account = True
        context = {
            'has_kyc': has_kyc,
            'has_account': has_account,
            'profile': profile,
        }
        
    else: 
        context = {} 
        
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                messages.success(request, "You Have Been Logged In!")
                return redirect('home') 
            else:
                messages.error(request, "Invalid username or password.")
    return render(request, 'home.html', context)



def logout_user(request):
	logout(request)
	messages.success(request, "You Have Been Logged Out...")
	return redirect('home')


def register_user(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username, password=password)
            auth_login(request, user)
            messages.success(request, "You Have Successfully Registered! Welcome!")
            return redirect('home')
    else:
        form = SignUpForm()
        return render(request, 'register.html', {'form':form})
    return render(request, 'register.html', {'form':form})

def kyc_profile_view(request):
    try:
        profile = request.user.customerprofile
    except CustomerProfile.DoesNotExist:
        # No profile exists yet
        profile = None

    if request.method == 'POST':
        # If updating, pass 'instance=profile'. If creating, instance is None.
        form = CustomerProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            # Don't save to DB yet
            new_profile = form.save(commit=False)
            # Link it to the current user
            new_profile.user = request.user
            # Now save
            new_profile.kyc_completed = True
            new_profile.save()
            messages.success(request, "KYC Profile saved successfully!")
            return redirect('home') # Redirect back to dashboard after saving
    else:
        # GET Request: Show the form
        # If updating, pass 'instance=profile'. If creating, instance is None.
        form = CustomerProfileForm(instance=profile)

    return render(request, 'kyc_form.html', {'form': form})


def create_account_view(request):
    # Basic logic: If user clicks, create a savings account (replace with a real form later)
    if not Account.objects.filter(user=request.user, account_type='SAV').exists():
         # Generate a unique account number (simple example)
        import random
        acc_num = f"SAV-{request.user.id}-{random.randint(1000, 9999)}" 
        Account.objects.create(
             user=request.user, 
             account_type='SAV', 
             account_number=acc_num
        )
        messages.success(request, "Savings Account Created!")
    else:
        messages.info(request, "You already have a Savings Account.")
    return redirect('home')

def account_summary_view(request):
    # Get all accounts belonging to the logged-in user
    accounts = Account.objects.filter(user=request.user)
    
    context = {
        'accounts': accounts
    }
    return render(request, 'account_summary.html', context)

def transaction_history_view(request):
    # Get all transactions linked to the accounts owned by the logged-in user
    user_accounts = Account.objects.filter(user=request.user)
    transactions = Transaction.objects.filter(account__in=user_accounts) # Filter transactions by user's accounts
    
    context = {
        'transactions': transactions
    }
    return render(request, 'transaction_history.html', context)

@login_required
def apply_loan_view(request):
    if request.method == 'POST':
        form = LoanApplicationForm(request.POST)
        if form.is_valid():
            loan_application = form.save(commit=False)
            loan_application.user = request.user # Link to current user
            loan_application.status = 'PEND' # Set initial status
            loan_application.save()
            # Optional: Calculate EMI here if needed
            messages.success(request, f"Your {loan_application.get_loan_type_display()} application has been submitted successfully!")
            return redirect('loan_status') # Redirect to loan status page
    else: # GET request
        form = LoanApplicationForm()
        
    return render(request, 'apply_loan.html', {'form': form})

# --- ADD THIS VIEW ---
@login_required
def loan_status_view(request):
    # Get all loan applications for the logged-in user
    loan_applications = LoanApplication.objects.filter(user=request.user)
    
    context = {
        'loan_applications': loan_applications
    }
    return render(request, 'loan_status.html', context)
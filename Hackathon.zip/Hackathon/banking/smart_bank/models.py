from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class CustomerProfile(models.Model):
    # This links the profile to the main User model
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    
    # Your new fields
    date_of_birth = models.DateField()
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    )
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    mobile_number = models.CharField(max_length=15)
    address = models.TextField()
    occupation = models.CharField(max_length=100)
    annual_income = models.DecimalField(max_digits=10, decimal_places=2)
    
    # Document Fields
    aadhaar_card = models.CharField(max_length=12)
    pan_card = models.CharField(max_length=10)
    
    # Image Upload Fields
    # Make sure to install Pillow: pip install Pillow
    passphoto = models.ImageField(upload_to='documents/photos/')
    signature = models.ImageField(upload_to='documents/signatures/')
    kyc_completed = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username

class Account(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    ACCOUNT_TYPES = (
        ('SAV', 'Savings'),
        ('CUR', 'Current'),
        ('FD', 'Fixed Deposit'),
    )
    account_type = models.CharField(max_length=3, choices=ACCOUNT_TYPES)
    account_number = models.CharField(max_length=20, unique=True)
    balance = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.get_account_type_display()} ({self.account_number})"

class Transaction(models.Model):
    account = models.ForeignKey(Account, on_delete=models.CASCADE, related_name='transactions')
    TRANSACTION_TYPES = (
        ('DEPOSIT', 'Deposit'),
        ('WITHDRAW', 'Withdrawal'),
        ('TRANSFER', 'Transfer'),
    )
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPES)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    timestamp = models.DateTimeField(default=timezone.now)
    description = models.CharField(max_length=100, blank=True, null=True) # Optional description

    def __str__(self):
        return f"{self.account.account_number} - {self.transaction_type} - {self.amount}"

    class Meta:
        ordering = ['-timestamp']

class LoanApplication(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    LOAN_TYPES = (
        ('PL', 'Personal Loan'),
        ('HL', 'Home Loan'),
        ('CL', 'Car Loan'),
        ('EL', 'Education Loan'),
    )
    loan_type = models.CharField(max_length=2, choices=LOAN_TYPES)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    tenure_months = models.IntegerField() # Loan duration in months
    
    STATUS_CHOICES = (
        ('PEND', 'Pending Review'),
        ('APPR', 'Approved'),
        ('REJ', 'Rejected'),
    )
    status = models.CharField(max_length=4, choices=STATUS_CHOICES, default='PEND')
    applied_at = models.DateTimeField(default=timezone.now)
    # You could add fields for calculated EMI, interest rate, etc. later

    def __str__(self):
        return f"{self.user.username} - {self.get_loan_type_display()} - {self.amount}"

    class Meta:
        ordering = ['-applied_at']
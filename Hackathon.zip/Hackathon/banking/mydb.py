import pymysql as mysql
dataBase = mysql.connect(
    host="localhost",
    user="root",
    passwd="password123"
)
cursorObject = dataBase.cursor()

cursorObject.execute("CREATE DATABASE bank")

print("ALL Done!")